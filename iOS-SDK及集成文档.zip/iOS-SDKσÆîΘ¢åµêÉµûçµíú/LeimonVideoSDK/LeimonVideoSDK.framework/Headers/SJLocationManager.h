//
//  SJLocationManager.h
//  WYLemonVideo
//
//  Created by AlongShi on 2020/6/1.
//  Copyright © 2020 shujin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SJLocationManager : NSObject
/**
 单列
 
 @return 单列
 */
+ (instancetype)sharedInstance;

+(void)attempDealloc;

/// latitude
@property (nonatomic, readonly ,assign) double latitude;

/// longitude
@property (nonatomic, readonly, assign) double longitude;

/// 地址
@property (nonatomic, readonly, copy) NSString *address;

/// 请求定位
/// @param isOnce 是否只请求一次
- (void)requestLocationServicesAuthorization:(BOOL)isOnce;

/// 定位回调
@property (nonatomic, copy) void (^locationBlock)(double latitude, double longitude, NSString * _Nullable address, NSError * _Nullable error);

/// 停止定位
- (void)stop;
@end

NS_ASSUME_NONNULL_END
