//
//  SJVideoSDK.h
//  WYLemonVideo
//
//  Created by AlongShi on 2020/4/14.
//  Copyright © 2020 shujin. All rights reserved.
//

#import "SJVideoConfig.h"
#import "SJPlayVideoModel.h"
#import "SJSessionModel.h"

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, SJVideoSDKErrorCode) {
    // 初始化授权错误
    SJVideoSDKErrorCodeAuthFailed = 0,
    // 视频呼叫错误
    SJVideoSDKErrorCodeCallFailed,
    // 网络请求出错
    SJVideoSDKErrorCodeNetworkFailed,
    // 重复发起呼叫出错
    SJVideoSDKErrorCodeRepeatFailed,
    // 加入房间错误
    SJVideoSDKErrorCodeJoinRoomFailed,
    // 加入房间入参错误
    SJVideoSDKErrorCodeJoinRoomInputParameterFailed,
    // 摄像头或麦克风权限受限错误
    SJVideoSDKErrorCodeVideoOrAudioAuthorizationStatusRestricted,
    // IM同账号被挤出房间错误
    SJVideoSDKErrorCodeIMKickFailed,
    // IM账号登录房间错误
    SJVideoSDKErrorCodeIMLoginFailed,
    // IM账号断开链接错误
    SJVideoSDKErrorCodeIMBreakLinkFailed,

};

typedef NS_ENUM(NSUInteger, SJVideoSDKState) {
    //开始呼叫
    SJVideoSDKStateCallStart = 0,
    //排队中
    SJVideoSDKStateCallQueue,
    //就绪等待接听
    SJVideoSDKStateCallReady,
    //停止呼叫
    SJVideoSDKStateCallEnd,
    //加入视频会议
    SJVideoSDKStateSessionStart,
    //停止视频会议
    SJVideoSDKStateSessionEnd,
    //最小化窗口
    SJVideoSDKStateSessionMinWindow
};

///电子签名结果
typedef NS_ENUM(NSUInteger, SJVideoSDKESignResultCode) {
    // 退出
    SJVideoSDKESignResultCodeQuit = 0,
    // 成功
    SJVideoSDKESignResultCodeSuccess,
    // 失败
    SJVideoSDKESignResultCodeFail,
};

///语言设置
typedef NS_ENUM(NSUInteger, SJVideoSDKlanguageCode) {
    // 未设置
    SJVideoSDKlanguageUnknown = 0,
    // 英文
    SJVideoSDKlanguageEn,
    // 简体中文
    SJVideoSDKlanguageZh_Hans,
    // 繁体中文
    SJVideoSDKlanguageZh_Hant,
};

///弹窗枚举
typedef NS_ENUM(NSUInteger, SJVideoSDKAlertControllerCode) {
    // 呼叫超时 是否继续等待
    /// confirmBlock：保持当前页面，继续等待
    /// cancelBlock：退出当前页面，结束呼叫
    SJVideoSDKAlertControllerCodeCallTimeout = 0,
    
    ///当前通话仅剩一人 当前会议仅剩你一人 是否退出会议？
    ///confirmBlock：退出会议，退出当前页面结束视频通话
    ///cancelBlock：不做处理
    SJVideoSDKAlertControllerCodeOnlyMyself,
    
    ///确认挂断
    ///confirmBlock 挂断退出
    ///cancelBlock：不做处理
    SJVideoSDKAlertControllerCodeConfirmHangup,
    
    ///权限受限跳转弹窗
    ///confirmBlock 跳转设置页面
    ///cancelBlock：不做处理
    SJVideoSDKAlertControllerCodeGoToSettingPage,

    
    ///提示信息
    ///提示信息不用回调处理
    SJVideoSDKAlertControllerCodToastMsg,
    
};

@protocol SJVideoSDKDelegate <NSObject>

/// 状态回调
/// @param state state
- (void)videoState:(SJVideoSDKState)state;

/// 状态回调
/// @param state state
- (void)videoState:(SJVideoSDKState)state model:( SJSessionModel *)model;

/// 异常
/// @param code code
/// @param message message
/// @param error error
- (void)videoError:(SJVideoSDKErrorCode)code message:(NSString *)message error:(NSError * _Nullable)error;

/// 自定义消息回调
/// @param content 内容
- (void)videoSystemNotification:(NSString *)content;

///// h5事件通知
///// @param params 参数
//- (void)videoEventNotificationWithParams:(NSMutableDictionary *)params;

/// 电子签名事件结果
/// @param code 0退出。1确认
/// @param result 确认状态的具体结果
/*
 result 成功数据结构
 {
     code = 0;
     data =     {
         imgUrl =         (
             "http://res-uat1.leimondata.cn/data-uat/nmp-counter-api-uat/20210105/1609820648670de34a512-2e13-42d8-b542-27ca5ed9627d.png"
         );
     };
     message = "操作成功！";
 }
 */
- (void)videoESignResult:(SJVideoSDKESignResultCode)code result:(NSDictionary *)result;

/// 弹窗事件回调
/// @param code 弹窗类型枚举
/// @param confirmBlock 确定
/// @param cancelBlock 取消或退出
- (void)videoAlertWithCode:(SJVideoSDKAlertControllerCode)code message:(NSString *)message confirmBlock:(void (^)(void))confirmBlock cancelBlock:(void (^)(void))cancelBlock;

/// 屏幕旋转通知
/// @param orientation 旋转方向
/// @param allowRotation 是否允许旋转 YES 允许
- (void)videoAllowRotation:(UIInterfaceOrientation )orientation allowRotation:(BOOL)allowRotation;
@end

//成功回调
typedef void (^SuccessBlock)(void);
//失败回调
typedef void (^FailureBlock)(NSError *error,SJVideoSDKErrorCode errorCode);

@interface SJVideoSDK : NSObject

/**
 单列
 
 @return 单列
 */
+ (instancetype)sharedInstance;

/// 代理对象
@property (nonatomic, weak) id<SJVideoSDKDelegate> delegate;

/// 打印控制台 默认NO
@property (nonatomic, assign) BOOL openLog;

/// 呼叫业务数据模型
@property (nonatomic, strong, readonly) SJPlayVideoModel *playVideoModel;

/// 配置
@property (nonatomic, readonly) SJVideoConfig *videoConfig;

/// 初始化接口
/// @param configParams 配置信息
- (void)registerWithConfigParams:(SJVideoConfig *)configParams;

/// 初始化接口
/// @param configParams 配置信息
/// @param complited 回调
- (void)registerWithConfigParams:(SJVideoConfig *)configParams complited:(void (^)(NSError * _Nullable error))complited;

/// 呼叫器业务
/// @param playVideoModel 呼叫参数
/// @param complited 状态回调
- (void)placeVideo:(SJPlayVideoModel *)playVideoModel complited:(void (^)(NSError *error))complited;


/// 发起电子签名
/// @param complited 回调结果 erroe = nil 发起成功
- (void)callESignWithComplited:(void (^)(NSError *error))complited;

/// 发起电子签名
/// @param ext 参数
/// @param complited 回调结果 erroe = nil 发起成功
- (void)callESignWithExt:(NSDictionary *)ext complited:(void (^)(NSError *error))complited;

/// 获取会话信息 （如果会话已经建立）
- (SJSessionModel *)getSessionInfo;

//// 发送自定义系统通知
/// @param content 内容
/// @param completion 回调
- (void)sendSystemNotificationWith:(NSString *)content completion:(nullable void (^)(NSError * __nullable error))completion;
    
///// 发送h5事件通知
///// @param params 参数
//- (void)sendVideoEventNotificationWithParams:(NSMutableDictionary *)params;

/// 开启悬浮窗
- (void)openFloatWindow;


/// /// 开启悬浮窗
/// @param animated 是否显示动画 YES显示
/// @param closeTap 是否关闭点击返回手势 YES关闭
/// @param completion 回调结果 YES开启悬浮窗成功 或已经是开启状态  NO开启失败
- (void)openFloatWindowWithAnimated:(BOOL)animated closeTap:(BOOL)closeTap completion:(void (^)(BOOL finished))completion;

/// /// 开启悬浮窗
/// @param completion 回调结果 YES开启悬浮窗成功 或已经是开启状态  NO开启失败
- (void)openFloatWindow:(void (^)(BOOL finished))completion;

/// 关闭悬浮窗
- (void)closeFloatWindow;

/// 关闭悬浮窗
/// @param completion 回调结果 YES关闭悬浮窗成功或已经是关闭悬浮窗状态  NO关闭失败
- (void)closeFloatWindowWithAnimated:(BOOL)animated completion:(void (^)(BOOL finished))completion;

/// 关闭悬浮窗
/// @param animated 是否显示动画 YES显示
/// @param completion 回调结果 YES关闭悬浮窗成功或已经是关闭悬浮窗状态  NO关闭失败
- (void)closeFloatWindowWithAnimated:(BOOL)animated completion:(void (^)(BOOL finished))completion;

/// 本地流截屏
/// @paramcompliteded
/// imageURL  图片地址
/// result  是否成功
/// message 请求返回信息
- (void)snapshotWithComplete:(void(^)(NSString * imageURL, BOOL result,NSString* message))complited;

/// 展示图片
/// @param imgUrl 图片URL地址
/// @param completion 结果回调
- (void)showAgreementImage:(NSString *)imgUrl completion:(void (^)(BOOL finished))completion;

/// 关闭展示图片
- (void)closeAgreement;

/// 版本号
- (NSString *)version;

/// 修改SDK语言
/// @param languageStyle 修改的语言类型 支持 简体中文、繁体中文和英文
- (void)changeLanguageTo:(SJVideoSDKlanguageCode)languageStyle;

/// 获取SDK设置的本地语言
- (SJVideoSDKlanguageCode)getLanguageStyle;
@end

NS_ASSUME_NONNULL_END
