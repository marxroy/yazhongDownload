//
//  SJmPaaSConfig.h
//  LeimonVideoSDk
//
//  Created by AlongShi on 2020/7/7.
//  Copyright © 2020 shujin. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// 阿里配置参数
@interface SJmPaaSConfig : NSObject
@property (nonatomic, copy) NSString *workspaceId;
@property (nonatomic, copy) NSString *appId;
@property (nonatomic, copy) NSString *bizName;
@property (nonatomic, copy) NSString *roomServerCustomUrl;

@end

NS_ASSUME_NONNULL_END
